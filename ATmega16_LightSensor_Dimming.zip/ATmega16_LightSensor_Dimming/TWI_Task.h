﻿/*
 * TWI_Task.h
 *
 * Created: 2016/2/5 下午 03:01:06
 *  Author: Marspeople2
 */ 


#ifndef TWI_TASK_H_
#define TWI_TASK_H_

// Initialize.
void TWI_Init(void);
// Write task trigger on.
void TWI_Write_On(void);
// Read task trigger on.
void TWI_Read_On(void);
// TWI task.
void TWI_Task(void);


#endif /* TWI_TASK_H_ */