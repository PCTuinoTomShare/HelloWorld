﻿/*
 * IO_Task.h
 *
 * Created: 2016/2/8 下午 11:05:32
 *  Author: Marspeople2
 */ 


#ifndef IO_TASK_H_
#define IO_TASK_H_

// IO port initialize.
void IO_Init(void);
// IO task.
void IO_Task(void);

#endif /* IO_TASK_H_ */