﻿/*
 * UART_Task.h
 *
 * Created: 2016/2/8 下午 10:48:33
 *  Author: Marspeople2
 */ 


#ifndef UART_TASK_H_
#define UART_TASK_H_

// UART initialize.
void UART_Init(void);
// UART transmit data.
void UART_Transmit_Task(void);
// UART received check.
void UART_Received_Check(void);

#endif /* UART_TASK_H_ */