﻿/*
 * Timer2_Task.h
 *
 * Created: 2016/2/8 下午 10:57:52
 *  Author: Marspeople2
 */ 


#ifndef TIMER2_TASK_H_
#define TIMER2_TASK_H_

// Timer #2 initialize.
void Timer2_Init(void);
// Timer #2 task.
void Timer2_Task(void);

#endif /* TIMER2_TASK_H_ */