﻿/*
 * BH1750FVI.h
 *
 * Created: 2016/4/17 下午 04:12:41
 *  Author: Tom Hsieh
 */ 


#ifndef BH1750FVI_H_
#define BH1750FVI_H_

#define BH1750FVI_WR        0x46    // BH1750FVI I2C device address + WR.
#define BH1750FVI_RD        0x47    // BH1750FVI I2C device address + RD.
#define BH1750FVI_MEASURE   0x10    // BH1750FVI measure command, continue mode with 1x

// BH1750FVI initialize.
void BH1750FVI_Init(void);
// BH1750FVI measure data trigger on.
void BH1750FVI_On_Measure(void);
// BH1750FVI data read trigger on.
void BH1750FVI_On_Read(void);
// BH1750FVI get measurement data.
void BH1750FVI_Get_Measure(void);

#endif /* BH1750FVI_H_ */