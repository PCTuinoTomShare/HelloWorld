﻿/*
 * TWI_Device_Task.h
 *
 * Created: 2016/4/17 下午 06:21:22
 *  Author: Tom Hsieh
 */ 


#ifndef TWI_DEVICE_TASK_H_
#define TWI_DEVICE_TASK_H_

// TWI device task dispatch.
void TWI_Task_Disp(void);


#endif /* TWI_DEVICE_TASK_H_ */