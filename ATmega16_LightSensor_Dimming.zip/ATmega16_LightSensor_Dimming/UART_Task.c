﻿/*
 * UART_Task.c
 *
 * Created: 2016/2/8 下午 10:50:04
 *  Author: Tom Hsieh
 */ 

#include <avr/io.h>
#include "UART_Task.h"
#include "var.h"

// UART initialize.
void UART_Init(void)
{
	// USART.
	// - Baud rate.
	// - 9600 bps @ 8MHz.
	UBRRH = 0;
	UBRRL = 50;
	// - 8 bit data ( default ).
	// - 1 stop ( default ).
	// - No parity ( default ).
	// - TX enable.
	// - RX enable & interrupt enable.
	UCSRB = 0x98;
	// Reset data.
	uart_trn_data[0] = 0xaa;
	uart_trn_data[1] = 0x00;
	uart_trn_data[2] = 0x55;
}

// UART transmit data.
void UART_Transmit_Task(void)
{
	// No data need transmit.
	if( uart_trn_cnt == 0 ){
		// Check flag bit, UART transmit task ready.
		temp1 = state_flag;
		temp1 &= 0x02;
		if( temp1 == 0 ){
			return;
		}
		// Clear flag bit.
		state_flag &= 0xfd;		
		// Check flag bit, sensing data or manual data.
		temp1 = state_flag;
		temp1 &= 0x04;
		uart_trn_data[1] = sens_adj_value;
		if( temp1 ){
			uart_trn_data[1] = man_adj_value;			
		}
		
		// Test.
		//uart_trn_data[0] = 0x30;
		//uart_trn_data[1] = 0x31;
		//uart_trn_data[2] = 0x0a;
				
		// Reset counter.
		uart_trn_index = 0;
		uart_trn_cnt = 3;
		return;
	}
	// Check shifter buffer.
	temp1 = UCSRA;
	temp1 &= 0x20;
	// Not empty.
	if( temp1 == 0x00 ){
		return;
	}
	// Data out.
	UDR = uart_trn_data[uart_trn_index];
	// Next data.
	++uart_trn_index;
	--uart_trn_cnt;
	// Data LED active.
	data_led_hold = 40;
}

// UART received check.
void UART_Received_Check(void)
{
	// Check UART received counter.
	// Not full.
	if( uart_rec_cnt < 12 ){
		return;
	}
	
	// Clear received counter.
	uart_rec_cnt = 0;
}
