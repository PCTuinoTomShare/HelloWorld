/*
 * ATmega16_LightSensor_Dimming.c
 *
 * Created: 2016/4/14 下午 08:34:18
 * Author : Tom Hsieh
 */ 

#include <avr/io.h>

#include "IO_Task.h"
#include "UART_Task.h"
#include "ADC_Task.h"
#include "Timer2_Task.h"
#include "TWI_Task.h"
#include "BH1750FVI.h"
#include "TWI_Device_Task.h"
#include "var.h"

int main(void)
{
	// IO port initialize.
	IO_Init();
	// UART initialize.
	UART_Init();
	// TWI initialize.
	TWI_Init();
	// Timer #2 initialize.
	Timer2_Init();
	// ADC initialize.
	ADC_Init();	
	// BH1750FVI initialize.
	BH1750FVI_Init();	
	// ADC start conversion.
	ADC_Conv_On();
	
    /* Replace with your application code */
    while (1) 
    {		
		//ADC task.
		ADC_Task();
		// Timer #2 task.
		Timer2_Task();
		// IO task.
		IO_Task();
		// TWI task.
		TWI_Task();
		// UART transmit task.
		UART_Transmit_Task();
		// TWI device dispatch.
		TWI_Task_Disp();
    }
}

