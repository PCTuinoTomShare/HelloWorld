﻿/*
 * BH1750FVI.c
 *
 * Created: 2016/4/17 下午 04:20:26
 *  Author: Tom Hsieh
 */ 

#include <avr/io.h>

#include "BH1750FVI.h"
#include "TWI_Task.h"
#include "var.h"

// BH1750FVI initialize.
void BH1750FVI_Init(void)
{
	// SLA + W.
	twi_addr = BH1750FVI_WR;
	// Command, trigger on measure.
	twi_data[0] = BH1750FVI_MEASURE;
	// On byte data to write.
	twi_data_cnt = 1;
	// Trigger on TWI.
	TWI_Write_On();

	while( twi_task_cnt < 4 ){
		TWI_Task();
	}
	
}

// BH1750FVI measure data trigger on.
void BH1750FVI_On_Measure(void)
{
	// SLA + W.
	twi_addr = BH1750FVI_WR;
	// Command, trigger on measure.	
	twi_data[0] = BH1750FVI_MEASURE;
	// On byte data to write.
	twi_data_cnt = 1;
	// Trigger on TWI.	
	TWI_Write_On();
	// Set flag bit, TWI busy.	
	twi_task_status |= 0x01;	
}

// BH1750FVI data read trigger on.
void BH1750FVI_On_Read(void)
{
	// SLA + R.
	twi_addr = BH1750FVI_RD;
	// 2 bytes data to read.
	twi_data_cnt = 2; 
	// TRigger on TWI.
	TWI_Read_On();	
	// Set flag bit, TWI busy.
	twi_task_status |= 0x01;	
}

// BH1750FVI get measurement data.
void BH1750FVI_Get_Measure(void)
{
	// Get sensing adjustment dimming value.
	temp2 = twi_data[0];
	temp2 <<= 8;
	temp2 |= twi_data[1];
	
	if( temp2 > 1023 ){	
		temp2 = 1023;		
	}
	
	temp2 >>= 2;
	temp1 = (uint8_t)temp2;	
	sens_adj_value = ~temp1;		
}