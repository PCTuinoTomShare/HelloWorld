﻿/*
 * IO_Task.c
 *
 * Created: 2016/2/8 下午 11:07:33
 *  Author: Marspeople2
 */ 

#include <avr/io.h>
#include "IO_Task.h"
#include "var.h"

// IO port initialize.
void IO_Init(void)
{
	// Port B.
	// - PB0 button input.
	// - PB1 Manual LED output.
	// - PB2 UART data active LED output.
	// -  Others output port.
	DDRB = 0xfe;
	// - Logic low output, PB0 output high for pull high.
	PORTB = 0x01;	
	// Port D.
	// - D0 as input port for UART RXD.
	// - D1 as output port for UART TXD.
	DDRD = 0xfe;
}

// IO task.
void IO_Task(void)
{
	// Check debounce counter.
	if( btn_dbc_cnt > 6 ){
		// About 30ms past.
		// Clear counter.
		btn_dbc_cnt = 0;
		// Input check.
		temp1 = PINB;
		temp1 &= 0x01; 		
		temp1 |= btn_pre_state;
		// Keep current as previous state.
		btn_pre_state = PINB;
		btn_pre_state &= 0x01;
		
		if( temp1 == 0 ){
			// Button pressed.			
			// Check flag bit, button not hold.
			temp1 = state_flag;
			temp1 &= 0x01;
			// Not pressed hold.
			if( temp1 == 0 ){				
				// Flag bit toggle.
				temp1 = state_flag;
				temp1 &= 0x04;				
				temp1 = ~temp1;
				temp1 &= 0x04;				
				state_flag &= 0xfb;
				state_flag |= temp1;				
			}			
			// Set flag bit, button hold.
			state_flag |= 0x01;
		}
		else{
			// No button press.
						
			// Clear flag bit.
			state_flag &= 0xfe;
		}
	}
	// State LED, Manual.
	temp1 = state_flag;
	temp1 &= 0x04;
	if( temp1 ){
		// On.
		PORTB |= 0x02;
	}
	else{
		// Off.
		PORTB &= 0xfd;
	}
	// UART data LED.
	if( data_led_hold ){
		PORTB |= 0x04;
	}
	else{
		PORTB &= 0xfb;
	}	
}