﻿/*
 * Timer2_Task.c
 *
 * Created: 2016/2/8 下午 10:59:04
 *  Author: Marspeople2
 */ 

#include <avr/io.h>
#include "Timer2_Task.h"
#include "var.h"

// Timer #2 initialize.
void Timer2_Init(void)
{
	// - CTC mode, no output.
	// - prescale 1024.
	//    8MHz xtal, 0.125us * 1024 = 128us.
	//    period, 128us * 256 = 32.768 ms.
	TCCR2 = 0x0f;
	// comparator.
	// - 5ms / 128us = 39.
	OCR2 = 39;
}

// Timer #2 task.
void Timer2_Task(void)
{
	// Check flag bit, OCF2.
	temp1 = TIFR;
	temp1 &= 0x80;
	if( temp1 == 0x00 ){
		return;
	}
	// Clear flag bit.
	TIFR |= 0x80;
	// About 5ms past.
	// Increase button debounce counter.	
	++btn_dbc_cnt;
	// Measure delay.
	if( measure_delay ){	
		--measure_delay;
	}
	// TWI task delay.
	if( twi_task_delay ){
		--twi_task_delay;
	}
	// UART data LED hold counter.
	if( data_led_hold ){	
		--data_led_hold;
	}						
	// UART received timeout.
	if( uart_rec_cnt ){
		++uart_rec_to;
		if( uart_rec_to == 40 ){
			// about 200ms past.
			uart_rec_to = 0;
			uart_rec_cnt = 0;
		}
	}	
}