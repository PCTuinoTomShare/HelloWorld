﻿/*
 * TWI_Device_Task.c
 *
 * Created: 2016/4/17 下午 06:23:26
 *  Author: Tom Hsieh
 */ 

#include <avr/io.h>

#include "TWI_Device_Task.h"
#include "BH1750FVI.h"
#include "var.h"

// TWI device task dispatch.
void TWI_Task_Disp(void)
{
	// Busy check.
	temp1 = twi_task_status;
	temp1 &= 0x01;
	if( temp1 ){
		return;
	}
	
	switch( twi_dev_task_cnt ){
		
		case 0:
			if( twi_task_delay == 0){		
				// Next task.
				++twi_dev_task_cnt;
			}
			break;
			
		case 1:
			BH1750FVI_On_Measure();
			// Reset delay counter.
			// - about 30 * 5ms = 150ms.
			measure_delay = 30;		
			// Next task.
			++twi_dev_task_cnt;
			break;
			
		case 2:
			if( measure_delay == 0 ){
				// Read measure data.
				BH1750FVI_On_Read();				
				// Next task.
				++twi_dev_task_cnt;
			}		
			break;		
		
		case 3:		
			// Get sensing adjustment dimming value.
			BH1750FVI_Get_Measure();
			// Reset delay counter.
			// - about 200 * 5ms = 1000ms.
			twi_task_delay = 200;
			// UART transmit task ready.
			state_flag |= 0x02;
			// Next task.
			twi_dev_task_cnt = 0;
			break;
	}
	
}