﻿/*
 * ADC_Task.c
 *
 * Created: 2016/4/16 下午 06:13:31
 *  Author: Tom Hsieh
 */ 

#include <avr/io.h>
#include "ADC_Task.h"
#include "var.h"

// ADC initialize.
void ADC_Init(void){
	// Reference AVCC.
	// ADC0 single end input.
	ADMUX = 0x40;
	// Single conversion mode.	
	// Clock division 128.
	ADCSRA = 0x87;
}

// ADC task.
void ADC_Task(void){
	// Busy check.
	temp1 = ADCSRA;
	temp1 &= 0x40;
	if( temp1 ){
		// Still busy.
		return;
	}
	
	// Get manual adjustment dimming value.
	temp2 = ADC;
	temp2 >>= 2;
	man_adj_value = (uint8_t)temp2;
		
	// Start conversion.
	ADCSRA |= 0x40;	
}

// ADC conversion trigger on.
void ADC_Conv_On(void){	
	ADCSRA |= 0x40;
}

