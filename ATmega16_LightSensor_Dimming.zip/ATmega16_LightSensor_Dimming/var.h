﻿/*
 * var.h
 *
 * Created: 2016/4/16 下午 06:40:22
 *  Author: user
 */ 


#ifndef VAR_H_
#define VAR_H_

// Temporary #1.
uint8_t temp1;
// UART received timeout.
uint8_t uart_rec_to;
// UART received counter.
uint8_t uart_rec_cnt;
// UART received data.
uint8_t uart_rec_data[13];
// UART transmit counter.
uint8_t uart_trn_cnt;
// UART transmit data.
uint8_t uart_trn_data[12];
// UART transmit data index.
uint8_t uart_trn_index;
// Button input debounce counter.
uint8_t btn_dbc_cnt;
// Button input previous state.
uint8_t btn_pre_state;
// State flag.
// - bit #0, button pressed hold.
// - bit #1, UART transmit task ready.
// - bit #2, 0, sensing automatic mode.
//			 1, manual mode.
uint8_t state_flag;
// TWI task counter.
uint8_t twi_task_cnt;
// TWI SLA.
uint8_t twi_addr;
// TWI word/control address.
uint8_t twi_word;
// TWI data.
uint8_t twi_data[8];
// TWI data index.
uint8_t twi_data_index;
// TWI data counter.
uint8_t twi_data_cnt;
// TWI task dispatch status flag.
// - bit #0, busy. 
uint8_t twi_task_status;
// Manual dimming value.
uint8_t man_adj_value;
// Sensing dimming value.
uint8_t sens_adj_value;
// TWI device task counter.
uint8_t twi_dev_task_cnt;
// Measure delay.
uint8_t measure_delay;
// TWI device task delay.
uint8_t twi_task_delay;
// UART data LED hold counter.
uint8_t data_led_hold;
// Temporary #2.
uint16_t temp2;

#endif /* VAR_H_ */