﻿/*
 * ADC_Task.h
 *
 * Created: 2016/4/16 下午 06:08:10
 *  Author: user
 */ 


#ifndef ADC_TASK_H_
#define ADC_TASK_H_

// ADC initialize.
void ADC_Init(void);
// ADC task.
void ADC_Task(void);
// ADC conversion trigger on.
void ADC_Conv_On(void);

#endif /* ADC_TASK_H_ */