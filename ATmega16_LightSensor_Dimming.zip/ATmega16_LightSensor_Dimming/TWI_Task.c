﻿/*
 * TWI_Task.c
 *
 * Created: 2016/2/5 下午 03:02:54
 *  Author: Marspeople2
 */ 

#include <avr/io.h>

#include "TWI_Task.h"
#include "var.h"

// Initialize.
void TWI_Init(void)
{
	//TWI ( I2C also ).
	// - 100KHz @ 4MHz.
	TWBR = 0x03;
	//TWCR = 0x04;
	// Reset variable.
	twi_task_cnt = 0;	
}

// Write task trigger on.
void TWI_Write_On(void){	
	// Reset task counter.
	twi_task_cnt = 1;
	// Send start condition.
	TWCR = 0xa4;	
}

// Read task trigger on.
void TWI_Read_On(void){
	// Reset task counter.
	twi_task_cnt = 6;
	// Send start condition.
	TWCR = 0xa4;	
}

// TWI task.
void TWI_Task(void)
{
	// Check interrupt flag.
	temp1 = TWCR;
	temp1 &= 0x80;
	if( temp1 == 0x00 ){
		return;
	}	
	// Clear flag bit.
	//TWCR |= 0x80;
	
	// Get status code.
	temp1 = TWSR;
	temp1 &= 0xf8;
	
	switch( twi_task_cnt ){
		
		// SLA + W was send.
		case 12:
			// Send control word.
			TWDR = twi_word;
			// 1.) Clear interrupt flag,
			// 2.) and trigger on.
			TWCR = 0x84;
			// Next task.
			++twi_task_cnt;		
			break;
		
		// Control word was send.
		case 13:
			// Restart condition.
			// 1.) Clear interrupt flag,
			// 2.) Start condition.
			// 3.) and trigger on.
			TWCR = 0xa4;			
			// Next task.
			++twi_task_cnt;		
			break;
				
		// SLA+R was send.
		case 15:
		case 7:
			// Check ACK or NACK.
			// NACK
			if( temp1 == 0x48){				
				// Stop condition out.				
				// 1.) Clear interrupt flag,
				// 2.) stop condition,
				// 3.) trigger on TWI.
				TWCR = 0x94;
				// Clear flag bit.
				twi_task_status &= 0xfe;
				// NACK check.				
				twi_task_cnt = 0;
				return;
			}
			// 1.) Clear interrupt flag.
			// 2.) Prepare received data and return ACK.
			// 3.) Trigger on.
			TWCR = 0xC4;										
			// Next task.
			++twi_task_cnt;			
			break;
		
		// Received data.
		case 16:
		case 8:
			// check status data received and ACK return.
				
			// Hold shifter data.
			twi_data[twi_data_index] = TWDR;
			// Next byte data.
			++twi_data_index;			
			--twi_data_cnt;
						
			// Check data counter.
			if( twi_data_cnt == 1 ){
				// Last data will receive.
				// Prepare receive first byte data.
				
				// 1.) Clear interrupt flag.
				// 2.) Received data and return NACK.
				// 3.) Trigger on.
				TWCR = 0x84;
				// Next task.
				++twi_task_cnt;				
			}
			else{
				// 1.) Clear interrupt flag.
				// 2.) Received data and return ACK.
				// 3.) Trigger on.
				TWCR = 0xC4;				
			}
			break;

		// All data received.
		case 17:
		case 9:
			// Hold shifter data.
			twi_data[twi_data_index] = TWDR;						
		// All data send.
		case 3:
			// Stop condition out.
			// 1.) Clear interrupt flag,
			// 2.) stop condition,
			// 3.) trigger on TWI.
			TWCR = 0x94;
			// Clear flag bit.
			twi_task_status &= 0xfe;
			// Next task.
			++twi_task_cnt;
			break;
		
		// SLA+W was send or
		// Data was send.
		case 2:
			// ACK or NACK check.
			// Only ACK.
			if( temp1 == 0x18 || temp1 == 0x28 ){						
				// Send data.
				TWDR = 	twi_data[twi_data_index];		
				// 1.) Clear interrupt flag, 
				// 2.) and trigger on.
				TWCR = 0x84;
				// Next data.
				--twi_data_cnt;
				++twi_data_index;		
				if( twi_data_cnt != 0 ){
					return;
				}		
				// Next task.
				++twi_task_cnt;
				return;
			}
			else if( temp1 == 0x20 ){				
				// Stop condition out.
				// 1.) Clear interrupt flag,
				// 2.) stop condition,
				// 3.) trigger on TWI.
				TWCR = 0x94;
				// Clear flag bit.
				twi_task_status &= 0xfe;
			}
			// Error check.
			twi_task_cnt = 0;						
			break;
		
		// Start condition was send.
		case 14:
			twi_addr |= 0x01;
		case 11:
		case 6:
		case 1:
			// Error check.
			if( temp1 != 0x08 ){
				twi_task_cnt = 0;
				return;				
			}					
			// Send SLA + W or SLA + R.
			TWDR = twi_addr;
			// 1.) Clear interrupt flag, 
			// 2.) and trigger on.
			TWCR = 0x84;
			// Clear data index.
			twi_data_index = 0;
			// Next task.
			++twi_task_cnt;
			break;
	}
	
	
	
		
}
